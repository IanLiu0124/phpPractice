<?php
include 'inc/functions.inc.php';

start($price,$discountThreshold);

?>